﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CANTestBox.Model
{
    public class TraceModel : ObservableObject
    {
        public TraceModel()
        {
            Time = "0";
            Dir = "Rx";
            CanID = "0x000";
            FrameType = "Error";
            Length = 0;
            Raw = "00 00 00 00 00 00 00 00";
        }

        private string time;
        public string Time
        {
            get
            {
                return time;
            }
            set
            {
                time = value;
                RaisePropertyChanged("Time");
            }
        }

        private string dir;
        public string Dir
        {
            get
            {
                return dir;
            }
            set
            {
                dir = value;
                RaisePropertyChanged("Dir");
            }
        }

        private string canid;
        public string CanID
        {
            get
            {
                return canid;
            }
            set
            {
                canid = value;
                RaisePropertyChanged("CanID");
            }
        }

        private string frametype;
        public string FrameType
        {
            get
            {
                return frametype;
            }
            set
            {
                frametype = value;
                RaisePropertyChanged("FrameType");
            }
        }

        private ushort length;
        public ushort Length
        {
            get
            {
                return length;
            }
            set
            {
                length = value;
                RaisePropertyChanged("Length");
            }
        }

        private string raw;
        public string Raw
        {
            get
            {
                return raw;
            }
            set
            {
                raw = value;
                RaisePropertyChanged("Raw");
            }
        }

    }
}
