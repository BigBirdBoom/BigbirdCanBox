﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CANTestBox.Model
{
    public enum HardWareVendor
    {
        USBCAN,
        Kvaser,
        ChuangXinII
    }
    public enum CANChn
    {
        Zero,
        One
    }
    public enum FilterMode
    {
        NoFilter,
        StdFrame,
        ExtFrame
    }
    public enum TestingMode
    {
        Normal,
        ListenOnly,
        SelfCheck
    }
    public class HardWareModel : ObservableObject
    {
        public HardWareModel()
        {

        }

    }
}
