﻿using CANTestBox.Model;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.CommandWpf;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CANTestBox.ViewModel
{
    public class TraceViewModel : ViewModelBase
    {
        public TraceViewModel()
        {
            TraceViewBuffer = new ObservableCollection<TraceModel>();
        }

        private ObservableCollection<TraceModel> traceviewbuffer = null;
        public ObservableCollection<TraceModel> TraceViewBuffer
        {
            get
            {
                return traceviewbuffer;
            }
            set
            {
                traceviewbuffer = value;
                RaisePropertyChanged("TraceViewBuffer");
            }
        }

        private RelayCommand traceTestCommand;
        public RelayCommand TraceTestCommand
        {
            get
            {
                if (traceTestCommand == null)
                {
                    traceTestCommand = new RelayCommand(TraceTest);
                }
                return traceTestCommand;
            }
        }
        private void TraceTest()
        {
            TraceViewBuffer.Add(new TraceModel() { Length = 1 });
            TraceViewBuffer.Add(new TraceModel() { Length = 2 });
            TraceViewBuffer.Add(new TraceModel() { Length = 3 });
            TraceViewBuffer.Add(new TraceModel() { Length = 4 });
        }
    }
}
