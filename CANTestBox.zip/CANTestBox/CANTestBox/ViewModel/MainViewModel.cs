using CANTestBox.Model;
using GalaSoft.MvvmLight;
using System.Collections.ObjectModel;

namespace CANTestBox.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        ObservableCollection<ViewModelBase> _children;
        public ObservableCollection<ViewModelBase> Children { get { return _children; } }
        public MainViewModel()
        {
            _children = new ObservableCollection<ViewModelBase>();
            _children.Add(new HardwareViewModel());
            _children.Add(new TraceViewModel());
        }
    }
}