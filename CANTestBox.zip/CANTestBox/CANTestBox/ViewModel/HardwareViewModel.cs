﻿using CANTestBox.Model;
using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CANTestBox.ViewModel
{
    public class HardwareViewModel : ViewModelBase
    {
        public HardwareViewModel()
        {
            Vendor = HardWareVendor.USBCAN;
            Chn = CANChn.Zero;
            FMode = FilterMode.NoFilter;
            TMode = TestingMode.Normal;
        }
        private HardWareVendor vendor = HardWareVendor.USBCAN;
        public HardWareVendor Vendor
        {
            get
            {
                return vendor;
            }
            set
            {
                vendor = value;
                RaisePropertyChanged("Vendor");
            }
        }
        private CANChn chn = CANChn.Zero;
        public CANChn Chn
        {
            get
            {
                return chn;
            }
            set
            {
                chn = value;
            }
        }
        private FilterMode fmode = FilterMode.NoFilter;
        public FilterMode FMode
        {
            get
            {
                return fmode;
            }
            set
            {
                fmode = value;
            }
        }
        private TestingMode tmode = TestingMode.Normal;
        public TestingMode TMode
        {
            get
            {
                return tmode;
            }
            set
            {
                tmode = value;
            }
        }
    }
}
